---
layout: page
title: Comments
comments: yes
---

Hey! Since you reach here, why not say something!?
