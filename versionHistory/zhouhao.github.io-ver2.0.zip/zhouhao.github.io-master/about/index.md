---
title: About me
layout: page
comments: yes
---
  
# Zhou Hao      
国内毕业于大连理工大学，专业计算机。自认一直在给母校丢人。当然母校当时给我也造成的深深的伤害：专业男女比例19：1至今让我与女生无法正常交流。      
       
目前就读于伍斯特理工，专业依旧计算机。现在一直努力想让自己成为一个interesting的人。   
       
我会编程。但是更多人不会。这真他妈的酷！（引用自笨方法学Python的结束语）      


<a target="_blank" href="http://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=IVtJTlRJQE5RTVRVTmFQUA9CTkw" style="text-decoration:none;">Contact Me</a>      
个人邮箱: [hzhou@wpi.edu](mailto:hzhou@wpi.edu "Send Me Email, and I can reply you in 5 Min")    
备用邮箱: [zhouhao@sbzhouhao.net](mailto:zhouhao@sbzhouhao.net "Yeah, I do not always check this.")     
新浪微博: [http://weibo.com/sbzhouhao](http://weibo.com/sbzhouhao "疯狂的咸蛋")       
GitHub:   [http://github.com/zhouhao](http://github.com/zhouhao "我写了一些很糟糕的代码在这里")       
LinkedIn: [http://www.linkedin.com/in/sbzhouhao](http://www.linkedin.com/in/sbzhouhao "我的个人介绍")       
*这个网站是托管在GitHub上的，[click here](https://github.com/zhouhao/zhouhao.github.io "find the code")*

<!--<iframe width="600" height="500" class="share_self"  frameborder="0" scrolling="no" src="http://widget.weibo.com/weiboshow/index.php?language=&width=600&height=500&fansRow=1&ptype=1&speed=0&skin=1&isTitle=1&noborder=1&isWeibo=1&isFans=1&uid=2184854490&verifier=72498178&dpc=1"></iframe>     
-->
