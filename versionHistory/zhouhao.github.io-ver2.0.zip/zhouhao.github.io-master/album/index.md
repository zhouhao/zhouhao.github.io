---
title: My Album
layout: page
comments: yes
---
<link rel="stylesheet" href="../media/css/colorbox.css" />
<script src="../media/js/jquery.colorbox.js"></script>
<script>
$(document).ready(function(){
//Examples of how to assign the Colorbox event to elements
$(".group").colorbox({rel:'group', slideshow:true});  		
});
</script>	
<h2>Album Initialization</h2>
<a class="group" href="http://mitchief.org/media-files/photo/20130411-xuxiaoping/img_7108.jpg" title="http://mitchief.org"><img src="http://mitchief.org/media-files/photo/20130411-xuxiaoping/img_7108.jpg" width="100" alt="1"></a>
<a class="group" href="http://farm9.staticflickr.com/8277/8940631287_27a74a6419_z.jpg" title="IMG_1036 by Zhou Hao, on Flickr"><img src="http://farm9.staticflickr.com/8277/8940631287_27a74a6419_z.jpg" width="100" alt="IMG_1036"></a>
<a class="group" href="http://farm3.staticflickr.com/2805/8941252442_4f0aa5ef34_z.jpg" title="IMG_0777 by Zhou Hao, on Flickr"><img src="http://farm3.staticflickr.com/2805/8941252442_4f0aa5ef34_z.jpg" width="100" alt="IMG_0777"></a>
<a class="group" href="http://farm8.staticflickr.com/7317/8940631901_2f95a32e1c_z.jpg" title="IMG_0911 by Zhou Hao, on Flickr"><img src="http://farm8.staticflickr.com/7317/8940631901_2f95a32e1c_z.jpg" width="100" alt="IMG_0911"></a>
<a class="group" href="http://farm4.staticflickr.com/3670/8940634287_aa5e9ebc03_z.jpg" title="IMG_0692 by Zhou Hao, on Flickr"><img src="http://farm4.staticflickr.com/3670/8940634287_aa5e9ebc03_z.jpg" width="100" alt="IMG_0692"></a>
<a class="group" href="http://farm9.staticflickr.com/8558/8940637473_95631e1e55_z.jpg" title="IMG_1049 by Zhou Hao, on Flickr"><img src="http://farm9.staticflickr.com/8558/8940637473_95631e1e55_z.jpg" width="100" alt="IMG_1049"></a>
<a class="group" href="http://farm4.staticflickr.com/3776/8932722450_bc78269a8c_z.jpg" title="IMG_1059 by Zhou Hao, on Flickr"><img src="http://farm4.staticflickr.com/3776/8932722450_bc78269a8c_z.jpg" width="100" alt="IMG_1059"></a>
<a class="group" href="http://farm8.staticflickr.com/7401/9012278129_62064655ae_z.jpg" title="这个是我偷拍的"><img src="http://farm8.staticflickr.com/7401/9012278129_62064655ae_z.jpg" width="100" alt="IMG_1514"></a>
<a class="group" href="http://farm8.staticflickr.com/7287/9013458306_8611c50aa1_z.jpg" title="IMG_1617 by Zhou Hao, on Flickr"><img src="http://farm8.staticflickr.com/7287/9013458306_8611c50aa1_z.jpg" width="100" alt="IMG_1617"></a>
<a class="group" href="http://farm4.staticflickr.com/3762/9013457718_d657a045f5_z.jpg" title="IMG_1591 by Zhou Hao, on Flickr"><img src="http://farm4.staticflickr.com/3762/9013457718_d657a045f5_z.jpg" width="100" alt="IMG_1591"></a>
<a class="group" href="http://farm4.staticflickr.com/3813/9013455532_0cece4a13a_z.jpg" title="这个小家伙太活跃了"><img src="http://farm4.staticflickr.com/3813/9013455532_0cece4a13a_z.jpg" width="100" alt="IMG_1525"></a>
<a class="group" href="http://farm4.staticflickr.com/3672/9620134912_f10d6b6baa_z.jpg" title="CSSA招新"><img src="http://farm4.staticflickr.com/3672/9620134912_f10d6b6baa_z.jpg" width="100" alt="CSSA招新"></a>
<a class="group" href="http://farm8.staticflickr.com/7350/9781036741_7d413c6f45_z.jpg" title="VSA-BBQ"><img src="http://farm8.staticflickr.com/7350/9781036741_7d413c6f45_t.jpg" width="100" alt="VSA-BBQ"></a>
<a class="group" href="http://farm6.staticflickr.com/5514/9867686833_937d02fa56_z.jpg" title="IMG_9665 by Zhou Hao, on Flickr"><img src="http://farm6.staticflickr.com/5514/9867686833_937d02fa56_t.jpg" width="100" alt="Mid-autumn frstival"></a>
