---
layout: post
title: "What I am doing now -- WPILIFE website"
description: "What I am doing now"
category: PHP
tags: [WPILIFE]
---
As I referred in my article: [*I'd like to make a website for new WPI student of house renting*](http://sbzhouhao.net/2013/07/Do-something-good-for-new-WPI-students/), a website is under construction now: [WPILIFE](http://wpilife.org/)(Just a start of finishing `register` function)   
What I have done:   
1. I bought a domain and rent a server in Goddady, because I don't have enough money to rent a Amazon server.[The shared server of Goddady is very unstable, which really annoys me]    
2. I bought the theme I used for this website here:[http://themeforest.net/item/nevia-responsive-html5-template/3708895?ref=wphub](http://themeforest.net/item/nevia-responsive-html5-template/3708895?ref=wphub), and it cost me $15(I also bought another one, which I have not used)    
3. I cost me very long time to setup git on that server, but it cannot fork repository from Github. Actually I can tolerate it, as a "poor" man.    
4. I choose Codeigniter to do this website, which is a open-source PHP structure. And it cost me many nights to read the document. ---- Great news is that I find CI is very efficient structure for me.         
5. [kindEditor](http://www.kindsoft.net/), which I will use as my online-editor      
6. .......(To be continue...)