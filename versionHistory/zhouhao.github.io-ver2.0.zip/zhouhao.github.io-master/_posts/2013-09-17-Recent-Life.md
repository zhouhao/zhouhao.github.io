---
layout: post
title: "At the beginning of the third term"
description: "At the beginning of the third term"
category: Life
tags: [Life In USA]
---
Ahha, a pretty busy term, bad news is that I haven't got into my daily school life as I have many other things to do.    
**09/12** I finished my new draft version resume, and went to CDC to get some advice for modification    
**09/13** Good news is that the internship boss found a guy in China to do help for me, so I will have more time focus on my own things   
**09/14** I went to buy a suit for coming career fair(cost me almost 700D), and this will be the first time to wear suit in my 24-year life   
**09/15** Do some help for Mid-autumn festival rehearsal    
**09/16** Go to Boston to have dinner with Aki(a startup founder, and we should have this dinner at the end og August, but both of us are busy, so it is delayed, until 2 days before career fair), Yeah, everyone is busy when I know he works about 12 hours everyday.     
**Now** Write this post, which is just a waste of reader's time.