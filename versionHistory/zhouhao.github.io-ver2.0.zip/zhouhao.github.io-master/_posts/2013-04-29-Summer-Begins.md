---
layout: post
title: "Summer Begins"
description: "Summer Holiday"
category: Life
tags: [study life]
---

伴随着最后一个Quiz的结束，这个暑假正式开始了。     
实话，在我Quiz未提交之前，手机一阵，感觉来邮件了，果然，提交Quiz后：   

    Hi Hao,

    We are prepared to have you in office daily from 9am to 5pm from now on.
    Please reply to confirm your time.  

    Thank you,
    Fang

可怜的一个没有暑假的人！    
网上买的自行车还没到，看来只能每天早上早起跑过去了。   
