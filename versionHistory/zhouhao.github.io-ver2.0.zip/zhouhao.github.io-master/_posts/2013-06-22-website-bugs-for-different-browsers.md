---
layout: post
title: "小站有点浏览器之间不兼容"
description: "website bugs for different browsers"
category: Browsers
tags: [Intro]
---

今天测试了一下小站在不同内核浏览器下的运行情况，不测不知道，一测吓一跳。

**在IE和Firefox中：**   
 
<img src="http://farm3.staticflickr.com/2823/9111154261_330ff76de3_z.jpg" width="516" height="267" alt="Tag cloud失效，并且揉做一团">   
  	Tag cloud失效，并且揉做一团      

<img src="http://farm4.staticflickr.com/3818/9111154303_518dd6d102_z.jpg" width="600" height="403" alt="这个地球统计Flash彻底破坏了页面的层次">     
	这个地球统计Flash彻底破坏了页面的层次
	（通过js导入的，还不好设置z-index。大家多看几眼吧，说不定哪天你再来访问，它就不见了）    

**现在能完全正确的运行的应该只有Chrome（Chromium也不行）**


#####我会慢慢花点时间来修改会替换的，在此mark一下 -- 还有，人人的那个名签图片加载实在是太慢了！
