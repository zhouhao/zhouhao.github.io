---
layout: post
title: "纯CSS的首页导航推荐"
description: "纯CSS的首页导航推荐"
category: Web
tags: [CSS]
---
<strike>I will finish it tomorrow. As before I finishing it, I should do some git operation on my unix system. Sorry</strike>
### Want to see the demo?! [Click me](http://sbzhouhao.net/demo/menu_demo.html "Menu demo"), and the total code is in that page, you can find that.
