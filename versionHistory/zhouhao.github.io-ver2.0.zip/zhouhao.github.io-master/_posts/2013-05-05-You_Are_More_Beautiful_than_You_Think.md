---
layout: post
title: "You Are More Beautiful than You Think"
description: "励志"
category: 励志
tags: [life]
---

<embed src="http://player.youku.com/player.php/sid/XNTUwOTgwNTYw/v.swf" allowFullScreen="true" quality="high" width="600" height="500" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>
<p style="text-align:center;">You Are More Beautiful than You Think. Be Happy, My Friends!</p>
