---
layout: post
title: "House Moving for Next Term"
description: "House Moving for Next Term"
category: house moving
tags: [life]
---
Today is Independence Day.    
But I did my house moving on 07/02 ~ 07/03.    
I was supposed to see the fireworks in Boston.


Below is a picture for Worcester.
<img src="http://farm8.staticflickr.com/7334/9210819647_1775298f06_z.jpg" width="640" height="480" alt="Worcester Bus Station">
