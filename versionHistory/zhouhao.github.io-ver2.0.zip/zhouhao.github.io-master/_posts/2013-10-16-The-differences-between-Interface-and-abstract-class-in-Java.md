---
layout: post
title: "The differences between 'Interface' and 'abstract class' in Java"
description: "The differences between 'Interface'and 'abstract class' in Java"
category: Java
tags: [Java]
---
Interface & abstract class are almost the same, but after you know some details, you will find that they are totally different.   

1. In Java, we cannot do multi-inherbition from a class, so interface is a compromise for multi-inherbition, I think.   
2. In interface, there can never be members, and every function is public, all of  which should be re-written if a class implement this interface.   
3. 
