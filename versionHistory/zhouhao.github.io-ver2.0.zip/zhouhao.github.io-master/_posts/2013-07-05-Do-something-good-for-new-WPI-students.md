---
layout: post
title: "I'd like to make a website for new WPI student of house renting"
description: "public welfare"
category: public welfare
tags: [public welfare]
---

I have an idea for this. And I will prepare for it.    
I wish I can finish it before Augest.  

####It is not so hard, but it seems useless.

###Even it seems useless, I will start it at github: [Life-service-web-for-WPI-Chinese-student](https://github.com/zhouhao/Life-service-web-for-WPI-Chinese-student)
