---
layout: post
title: "Shopping List for New house"
description: "Shopping List for New house"
category: life
tags: [life]
---


I will begin to move into my new house since this weekend, so I need to buy some daily necessities.

Common use:
>1.Dining table with chairs    
>2.Router   
>3.power strip   
>4.Wash liquid  
>5.Sauce for cooking  
>6.Rice cooker    
>7.Electric Kettle    
>8.....

Personal use:
>1.Desk   
>2.LCD monitor   
>3.Chair for desk   
>4.....


When you are in the mall, I know my shopping list will much much longer than this.
