---
layout: post
title: "Amazing Dance"
description: "Amazing Dance"
category: Video
tags: [Art]
---

<object width="600" height="480"><param name="movie" value="http://share.vrs.sohu.com/1172908/v.swf&autoplay=false&xuid="></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed width="600" height="480"  allowfullscreen="true" allowscriptaccess="always" quality="high" src="http://share.vrs.sohu.com/1172908/v.swf&autoplay=false&xuid=" type="application/x-shockwave-flash"/></embed></object>
