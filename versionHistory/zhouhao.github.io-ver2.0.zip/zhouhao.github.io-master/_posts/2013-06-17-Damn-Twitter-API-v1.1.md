---
layout: post
title: "Twitter API版本更新带给我的深深伤害"
description: "Twitter API版本更新带给我的深深伤害"
category: Python
tags: [Twitter API, Volunteer]
---
清晰记得6月11号，突然程序不跑了，当时幼稚的以为是自己发的request太快，收到了Twitter的惩罚，后来证实是自己想多了：**那天Twitter彻底淘汰了就版本的API**。      

问题是：新版本的API需要身份认证，我已经整了好久了，都不知道怎么在发request的时候加入认证，后来即使我按照给的demo片段加入request header，靠！！！！！！！根本就不好用！！！！

蛋都碎了好不好！！！！！！！！！害的我给了一个临时的版本（一个其他公司给的一个beta的API，可以获取Twitter的数据）给同组的一个人用。（顺便在此感谢这位外国友人给了我一个dota2的邀请，虽然我知道我短时间内不会去得瑟。）

<img src="http://farm6.staticflickr.com/5490/9071599957_3f0a142567_z.jpg" width="603" height="440" />      
图我也不去处理了，那些敏感信息的有效时间也就十几分钟，等你看到这个图的时候，它们也已经失效了。


*有谁有这方面的经验吗？求指教，求虐！*
